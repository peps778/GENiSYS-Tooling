# GENiSYS Tooling — Forensics / File Analysis module

Drop-in feature module for `src/components/FileAnalysis/` in the GENiSYS
Astro + React + Tailwind SPA.

## Integration

1. Copy this entire folder to `src/components/FileAnalysis/` in the GENiSYS
   repo.
2. In `GenisysApp.tsx` (or wherever the shell wires up routes), import and
   render the page inside the existing main content area:

   ```tsx
   import { FileAnalysisPage } from "@/components/FileAnalysis";

   // ...inside the existing route switch:
   case "forensics":
     return <FileAnalysisPage />;
   ```

   No `BrowserRouter`, shell, or sidebar changes are needed — the module owns
   no routing or layout chrome beyond its own content.

3. Make sure your bundler is configured to load `.worker.ts` files as Web
   Workers. Vite (which Astro uses) supports this out of the box via
   `new Worker(new URL(...), { type: "module" })`, which is exactly the
   pattern used in `lib/fileAnalysisWorkerClient.ts` — no extra Vite config
   should be required, but if your project pins a non-default `worker`
   format, confirm `format: "es"` is set for module workers.

4. If your project's `tsconfig.json` doesn't already include both the `DOM`
   and separate `WebWorker` typings for worker files, add (or confirm) a
   worker-specific TS project reference. The worker file already declares
   `/// <reference lib="webworker" />` at the top, which is sufficient for
   most Vite + TS setups without further config.

## What was verified in this environment

This sandbox has no network access, so the project's real `vitest`,
`@types/react`, and other npm dependencies could not be installed here.
Instead, verification was done as follows:

- **Type safety of all pure logic** (`types/`, `lib/`, `workers/`,
  `tests/`): compiled cleanly with a strict, `noUnusedLocals` /
  `noUnusedParameters` TypeScript config (`tsc --noEmit`), once under a
  `DOM` lib context and once under a `WebWorker` lib context (matching how
  a real project typechecks app code vs. worker code separately).
- **All 86 unit tests pass.** Since `vitest` itself couldn't be installed
  offline, a minimal API-compatible shim (`describe`/`it`/`expect` with the
  matchers actually used by these tests) was used to execute the real test
  files unmodified via `tsx`. Every test file listed in the spec exists and
  passes: `fileIdentifier`, `metadataExtractor`, `stringExtractor`,
  `hexReader`, `imageAnalyzer`, `archiveInspector`, `steganography`,
  `binaryAnalyzer`, `fileReconstructor`, `fileSignatures`, `formatGuesser`.
- **`.tsx` component files** could not be fully typechecked here (no
  `@types/react` available offline), so they were reviewed manually for
  type consistency, unused imports/variables, and correct prop wiring.
  Once this folder is inside the real project with its existing
  `react`/`@types/react`/`vitest` dependencies, run:

  ```bash
  npm test
  npx tsc --noEmit
  ```

  to confirm end-to-end in the real environment.

## Notable implementation choices

- **Buffer handling**: when a file is loaded, one `Uint8Array` copy is kept
  on the main thread (for the Hex Viewer, string/candidate export, and
  on-demand hashing) and a second copy is transferred (zero-copy) into the
  analysis worker. This is a single, deliberate duplication — not a
  per-operation copy — needed because the worker's input buffer is
  transferred and therefore detached from the caller.
- **Conservative confidence levels**: every signature match carries
  `"confirmed" | "probable" | "unknown"`, and a matching file extension can
  never upgrade a signature's confidence — it can only be flagged as
  mismatched.
- **No fabricated results**: EXIF, advanced PDF metadata, and non-ZIP
  archive formats are explicitly reported as unavailable/unsupported rather
  than guessed. Steganography and recovery panels use hedged language
  ("candidate", "unexpected trailing bytes") rather than asserting hidden
  data or recoverability.
- **Bounded UI**: strings are paginated (100/page) and capped at 5,000
  matches per worker pass (10,000 on manual re-extraction); the hex viewer
  renders a fixed 32-row window and reads directly from the in-memory
  `Uint8Array` rather than building one giant string.

## CTF / Reverse-Engineering Workbench

The module now includes a CTF-focused layer without changing the existing
GENiSYS visual language or requiring a backend.

### CTF Triage

After every file analysis, the worker correlates the existing forensic results
with challenge-oriented indicators:

- common flag-shaped tokens such as `flag{...}` / `CTF{...}`;
- credential/secret-like assignments;
- URLs, IPv4 addresses, email-like identifiers;
- command/interpreter and common CTF-tool references;
- encoding/crypto keywords;
- interesting strings and embedded file signatures;
- bounded 7-bit/8-bit bitstream checks;
- Base64-looking transform candidates;
- a heuristic triage score and recommended first commands.

Every item is presented as a **lead**, not proof. Offsets can be sent directly
to the existing Hex Viewer.

### Executable analysis

ELF and PE headers are parsed in-browser. The UI exposes:

- architecture and bitness;
- entry point and mapped file offset;
- section table;
- interesting API/symbol-like strings;
- a lightweight x86/x86-64 instruction decoder;
- pseudo-C-style explanations for supported instructions;
- direct instruction-to-Hex navigation.

Mach-O magic is recognized conservatively. Unsupported instructions are shown
as unknown bytes rather than being guessed.

This is intentionally a browser-friendly CTF aid, not a replacement for a full
reverse-engineering engine such as Ghidra, IDA, Binary Ninja, Capstone, or
radare2.

### Safe virtual CTF shell

The **CTF Shell** tab behaves like a small Linux-inspired analysis console,
but it never creates a host process, touches the host filesystem, opens a
network connection, or executes the uploaded binary.

Supported commands include:

```text
file
sha256sum
strings
grep
xxd
hexdump
binwalk
entropy
readelf -h
objdump -d
base64 -d
cat
help
```

Text pipelines such as:

```text
strings | grep -i flag
strings | grep -Ei "password|secret|token"
```

are supported. This makes beginner workflows feel familiar while keeping the
analysis entirely inside the browser's in-memory file buffer.

### Tests added

Additional tests cover:

- CTF flag / credential / network indicator detection;
- ELF and PE recognition;
- executable analysis smoke paths;
- virtual shell commands and pipelines.

The original forensic tests remain in place. Run the project's normal:

```bash
npm test
npx tsc --noEmit
```

after installing the project's dependencies.

### Important execution boundary

An uploaded native executable is **never run automatically**. A real native
sandbox would require an isolated execution environment and substantially
different security boundaries. The current module instead gives the user the
safe equivalent of common reconnaissance commands over the file bytes and
provides browser-side executable inspection.
